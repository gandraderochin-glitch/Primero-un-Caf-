# Primero un Café — Sitio exportado

Este repositorio contiene una exportación del sitio "Expreso Matutino" tomada desde la instancia de preview.

Cómo funciona:

- Subiste un ZIP exportado desde el navegador: `descargaespressomat_files.zip`.
- El workflow de GitHub Pages extrae ese ZIP y despliega su contenido como sitio estático.
- `index.html` en la raíz es un contenedor que carga el contenido extraído desde `descargaespressomat_files/loading-preview.html`.

Si necesitas actualizar la página:

1. Abre la URL original en tu navegador.
2. Guarda la página completa (Ctrl+S / Guardar como -> Página web, completa).
3. Reemplaza `descargaespressomat_files.zip` en la raíz del repo con la nueva versión (subiendo el ZIP).
4. La acción se ejecutará automáticamente y publicará la versión actualizada.

---
Si querés que reordene archivos en el repo en lugar de usar el ZIP para desplegar, decímelo y lo hago (requiere extraer y subir los archivos).